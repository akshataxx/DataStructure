/*
 * ======================================================================
 * Written by: C3309266, Akshata Dhuraji
 * Written for: SENG2200 Programming Languages & Paradigms Assignment3
 * ======================================================================
 * Description: Stores the time related to the processing of the item, i.e.time an item enters and exits a stage of production
 */

public class Time implements Comparable<Time>{
    private double beginTime;//Start time of production
    private double finishTime;//End time of production
    private Stage stage;//Stage event occurs at

    public Time()//Constructor
    {
        beginTime = 0.0;
        finishTime = 0.0;
        stage = null;
    }
    //setters
    public void setBeginTime(double beginTime_)//Set start time
    {
        beginTime = beginTime_;
    }

    public void setFinishTime(double finishTime_)//Set end time
    {
        finishTime = finishTime_;
    }

    public void setStage(Stage stage_)//Set stage
    {
        stage = stage_;
    }
    //getters
    public Stage getStage()//Return stage
    {
        return stage;
    }

    public double getFinishTime()//Return endTime
    {
        return finishTime;
    }

    @Override
    public int compareTo(Time time)//For comparing data
    {
        if (finishTime < time.getFinishTime())
        {
            return -1;
        }
        else if (finishTime == time.getFinishTime())
        {
            return 0;
        }
        else
        {
            return 1;
        }
    }
}