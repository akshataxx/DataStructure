/*
 * ======================================================================
 * Written by: C3309266, Akshata Dhuraji
 * Written for: SENG2200 Programming Languages & Paradigms Assignment3
 * ======================================================================
 * Description: Replicates stage functionality i.e. takes the item from input queue,
 * computes processing time and moves object to output queue
 *
 *  Queue<Item> outputQueue: queue stores items output from stage
 *  Queue<Item> inputQueue:queue storing items not yet entered stage
 *  Item current: current Item in the stage
 *  double ProcessingTime: Total time spent in producing items
 *  double blockTime: time stage is blocked at
 *  double totalBlockTime: Total time the stage remained blocked
 *  int maxSize: Maximum size of output queue
 *  boolean starved: shows if the stage is starved
 *  boolean blocked: shows if the stage is blocked
 *  double inputTimeAt[]: time the input queue spends at a particular size
 *  double inputTime : Captures change in time at input
 *  double outputTimeAt[]: time the output queue spends at a particular size
 *  double outputTime: Time at output
 *  double timeDone: time at end of production
 *  double starveTime: time stage is starved at
 *  double totalStarveTime: Total time spent starving
 *  String stageName : Name of the stage
 *
 * public Data operations(double currentTime)
 * Description: Takes item from input queue, places in output queue and creates Data to store details
 *
 * updateInputTimeAt(currentTime, inputQueue.size())
 * Description: set inputQueue time and size
 *
 * updateOutputTimeAt(currentTime, outputQueue.size());
 * Description: similar to above function set time and size of outputQueue
 *
 * public double measureProdTime(double currentTime)
 * Description: Calculates production time and returns it
 *
 * public void setTotalProcessingTime(double newTime)
 * Description: Sets production time of stage
 *
 * public double getAverageSize()
 * Description: calculates and returns average size of output queue
 */

import java.util.*;

public class Stage {
    protected Queue<Item> outputQueue, inputQueue;
    protected Item currentItem;
    protected double ProcessingTime,range,blockTime,totalTimeBlock,timeDone,inputTime,starveTime,outputTime,totalTimeStarve;
    protected double inputTimeAt[],outputTimeAt[];
    protected int mean, maxSize;
    protected String stageName;
    protected boolean starved, blocked;


    public Time operations(double currentTime)
    {
        //check if completed
        if (!isCompleted(currentTime))
        {
            return null;
        }
        //check if starved
        if (!inputQueue.isEmpty())
        {
            if (starved)
            {
                starved = false;
                setUnStarveTime(currentTime);
            }
        }
        else
        {
            starved = true;
            setStarveTime(currentTime);
            return null;

        }
        //check if blocked
        if (outputQueue.size() < maxSize)
        {
            if (blocked)
            {
                blocked = false;
                setUnblockTime(currentTime);
            }
        }
        else
        {
            blocked = true;
            setBlockTime(currentTime);
            return null;
        }

        updateInputTimeAt(currentTime, inputQueue.size());
        itemProcessing();

        updateOutputTimeAt(currentTime, outputQueue.size()); //set times at sizes for outputQueue
        currentItem.setStage(this); //sets stage with the current item

        Time data;
        data=timeProcessing(currentTime);
        return data;
    }

    public void itemProcessing(){
        currentItem = inputQueue.poll(); //Removes item from input queue
        outputQueue.add(currentItem); //Adds item into output queue
    }

    public Time timeProcessing(double currentTime){
        Time data = new Time(); //creates object of Time class
        data.setBeginTime(currentTime);//sets the starttime as current time

        double prodTime = measureProdTime(currentTime);
        timeDone = currentTime + prodTime;

        currentItem.setTimeInQueue(stageName, prodTime); //sets time spent in prodution line for the current item
        data.setFinishTime(timeDone); //sets end time of prod in Data
        data.setStage(this); //sets stage in time
        return data;
    }

    public void updateOutputTimeAt(double currentTime, int size)
    {
        double timeGap = currentTime - outputTime;
        outputTime = currentTime;
        if (size!=0)
        {
            outputTimeAt[size-1] = outputTimeAt[size-1] + timeGap;
        }
    }

    public void updateInputTimeAt(double currentTime, int size)
    {
        double timeGap = currentTime - inputTime;
        inputTime = currentTime;
        if (size!=0)
        {
            inputTimeAt[size-1] = inputTimeAt[size-1] + inputTime;
        }
    }

    public String getAverageSize(){
        double avgSize = 0;
        int i=0;
        while ( i < outputTimeAt.length)
        {
            avgSize = avgSize + (i*outputTimeAt[i]);
            i++;
        }
        avgSize = avgSize/10000000.0;
        return String.format("%4.2f",avgSize);
    }
    //Returns stage name
    public String getStageName(){
        return stageName;
    }

    //Checks and returns boolean value if item has completed production time
    public boolean isCompleted(double currentTime){
        if(currentTime < timeDone) {
            return false;
        }
        else{
            return true;
        }
    }

    public double measureProdTime(double currentTime){
        double processingTime = 0.0;
        Random r = new Random();
        Double d = r.nextDouble(); //as per assignment specs

        // P = M + N x (d - 0.5)
        processingTime = mean + range * (d-0.5);
        // T2 = T1 + P.
        ProcessingTime = ProcessingTime + processingTime;
        return processingTime;
    }

    //returns total production time of stage
    public String processingTime(){
        double timeLimit = 10000000.0;//max time is 10,000,000 as per assignment spec
        ProcessingTime= ((ProcessingTime/timeLimit)*100); //computes work time %
        return String.format("%4.2f",ProcessingTime);
    }
    //Returns stage block status
    public boolean chkBlocked(){
        return blocked;
    }

    //Returns stage starve status
    public boolean chkStarved(){
        return starved;
    }

    //Set time to block stage
    public void setBlockTime(double currentTime){
        blockTime = currentTime;
    }

    //Set time stage unblocks
    public void setUnblockTime(double currentTime){
        double timeSpent = currentTime - blockTime;
        totalTimeBlock = totalTimeBlock + timeSpent;//computation of total blocktime
    }

    //Set the time when stage is starved
    public void setStarveTime(double currentTime){
        starveTime = currentTime;
    }
    //Set the time when the stage got unstarved
    public void setUnStarveTime(double currentTime){
        double timeSpent = currentTime - starveTime;
        totalTimeStarve = totalTimeStarve + timeSpent; //computation total starve time
    }

    //Get total time stage is starved
    public String getTotalTimeStarve(){
        return String.format("%4.2f",totalTimeStarve);
    }
    //Return total time stage blocked for
    public String getTotalTimeBlock(){
        return String.format("%4.2f",totalTimeBlock);
    }
}
