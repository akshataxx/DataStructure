/*
 * ======================================================================
 * Written by: C3309266, Akshata Dhuraji
 * Written for: SENG2200 Programming Languages & Paradigms Assignment3
 * ======================================================================
 * Description: Processing for the InterStageStorage  of the production line, extends stage
 */
import java.util.*;

public class InterStageStorage extends Stage {

    public InterStageStorage(Queue<Item> InputQueue_, String StageName_, int Mean_, double timeRange, int Size_)//Constructor
    {
        inputQueue = InputQueue_;
        outputQueue = new LinkedList<Item>();
        stageName = StageName_;
        mean = Mean_;
        range = timeRange;
        maxSize = Size_;
        inputTimeAt = new double[maxSize+1];
        outputTimeAt = new double[maxSize+1];
    }
    public void setOutputQueue(Queue<Item> prodQueue)//Set outputQueue
    {
        outputQueue = prodQueue;
    }

    public Queue<Item> getOutputQueue()//Return outputQueue
    {
        return outputQueue;
    }

    public Queue<Item> getInputQueue()//Return inputQueue
    {
        return inputQueue;
    }


    public String toString(){
        String printer = "";
        printer += getStageName()+ "\t\t\t" +processingTime()+ "\t\t" +getTotalTimeStarve()+ "\t\t" +getTotalTimeBlock();
        return printer;
    }

}