/*
  * ======================================================================
  * Written by: C3309266, Akshata Dhuraji
  * Written for: SENG2200 Programming Languages & Paradigms Assignment3
  * ======================================================================
  * Description: ProductionLine for processing input passed by PA3, generates the output and sends to PA3 for displaying
  */
 import java.util.*;
 import java.io.*;

 public class ProductionLine {
     private Queue<Item> prodQueue;//Queue structure used to depict production line as the processing begins at s0 and ends at s5
     private PriorityQueue<Time> dataQueue;//Priority queue implemented for discrete event simulation
     private Time data; //object of Time class to store current data while being processed
     private ArrayList<Stage> sequence;//Stores stages
     private Stage s0, s1, s2a, s2b, s3, s4a, s4b, s5;//object of Stage class depicting production stages as per assignment specs
     private Stage stage;//object of Stage class to store current stage data

     private int itemCount;//count of items passing through the production line
     private double currentTime;//variable for time
     private double timeLimit; //simulation time limit
     private int sPos; //Index number of sequence

     private int avgTime;//mean time accepted as input from the user in PA3
     private double timeRange;//n accepted as input from the user in PA3
     private int qSize;//Qmax accepted as input from the user in PA3

     public ProductionLine(int m,double n,int qMax){
         avgTime=m; //mean user input
         timeRange=n; //n user input
         qSize=qMax; //Qmax user input
         sequence = new ArrayList<Stage>(); //Stores stages
         dataQueue = new PriorityQueue<Time>();
         currentTime = 0.0;//Set current time to 0
         timeLimit = 10000000.0;//Set max time to 10,000,000 as defined in assignment specs
         data = null;//initial value of time class object
         stage = null;//initial value of stage class object

     }

     public void execute(){
         s0 = new StartStage(avgTime, timeRange, qSize);//Instantiate stage 0
         Queue<Item> prodQueue = ((StartStage)s0).getQueue();//At stage0, item is processed and output moves to production queue

         s1 = new InterStageStorage(prodQueue, "s1", avgTime, timeRange, qSize); //Stage 1 receives the input from stage0 output
         prodQueue = ((InterStageStorage)s1).getOutputQueue();//At stage1, item is processed and output moves to moves to production queue

         // Stage S2a/b will have mean and range valuese of 2M and 2N,
         s2a = new InterStageStorage(prodQueue, "s2a", (2*avgTime), (2*timeRange), qSize);//Stage 2a receives input from stage 1 output
         s2b = new InterStageStorage(prodQueue, "s2b", (2*avgTime), (2*timeRange), qSize);//Stage 2b receives input from stage 1 output
         prodQueue = ((InterStageStorage)s2a).getOutputQueue(); //item is processed and output of 2a moves to production queue
         ((InterStageStorage)s2b).setOutputQueue(prodQueue);//item is processed and output of 2b moves to production queue

         s3 = new InterStageStorage(prodQueue, "s3", avgTime, timeRange, qSize);//Stage 3 receives input from stage 2a & b
         prodQueue = ((InterStageStorage)s3).getOutputQueue();//item is processed and output of stage3 moves to production queue

         //Stage S4a/b will have mean and range valuese of 2M and 2N,
         s4a = new InterStageStorage(prodQueue, "s4a", (2*avgTime), (2*timeRange), qSize);//Stage 4a receives input from stage 3 output
         s4b = new InterStageStorage(prodQueue, "s4b", (2*avgTime), (2*timeRange), qSize);//Stage 4b receives input from stage 3 output
         prodQueue = ((InterStageStorage)s4a).getOutputQueue(); //item is processed and output of stage4a moves to production queue
         ((InterStageStorage)s4b).setOutputQueue(prodQueue);//item is processed and output of stage4b moves to production queue

         s5 = new FinishStage(prodQueue, avgTime, timeRange, qSize);//Stage 3 receives input from stage 4a & b, since its last stage input is moved to output post processing

         //Create sequence of stages
         sequence.add(s0);
         sequence.add(s1);
         sequence.add(s2a);
         sequence.add(s2b);
         sequence.add(s3);
         sequence.add(s4a);
         sequence.add(s4b);
         sequence.add(s5);

         sPos = 0; //index to get stages from array
         data = sequence.get(sPos).operations(currentTime); //set data to process first item
         dataQueue.add(data); //add data just created to the data queue calls the Time class

         //simulation of production line until timelimit is reached
         while(currentTime < timeLimit && !dataQueue.isEmpty())
         {
             data = dataQueue.poll();
             currentTime = data.getFinishTime(); //update currentTime to end time of data in dataQueue
             stage = data.getStage();
             String stageName = stage.getStageName();
             if(stageName=="s0"){
                 sPos = 0;}
             else if (stageName=="s1"){
                 sPos = 1;}
             else if (stageName=="s2a"){
                 sPos = 2;}
             else if (stageName=="s2b"){
                 sPos = 3;}
             else if (stageName=="s3"){
                 sPos = 4;}
             else if (stageName=="s4a"){
                 sPos = 5;}
             else if (stageName=="s4b"){
                 sPos = 6;}
             else if (stageName=="s5"){
                 sPos = 7;}
             else
             {throw new IllegalStateException("Invalid stage");}

             data = stage.operations(currentTime);
             if (data != null)
             {
                 dataQueue.add(data);
             }
             operations(data, sPos, currentTime);
         }
     }

     //Check production input and output stage, if not starved or blocked move item through the production line stages
     public void operations(Time data, int sPos, double currentTime){
         if (data ==null){
             //return
         }
         else{
             switch (sPos){
                 case 1://for stage 1 or 3
                 case 4:
                     data = sequence.get(sPos-1).operations(currentTime); //0 or 2b
                     if (data!=null)
                     {
                         dataQueue.add(data);
                     }
                     data = sequence.get(sPos+1).operations(currentTime); //2a or 4a
                     if (data!=null)
                     {
                         dataQueue.add(data);
                     }
                     data = sequence.get(sPos+2).operations(currentTime); //2b or 4b
                     if (data!=null)
                     {
                         dataQueue.add(data);
                     }
                     if(sPos==4) {
                         data = sequence.get(sPos-2).operations(currentTime); //2a
                         if (data!=null)
                         {
                             dataQueue.add(data);
                         }
                     }
                     break;
                 case 2://For stage 2a or 4a
                 case 5:
                     data = sequence.get(sPos-1).operations(currentTime); //Fetch Stage 1 or stage 3 output
                     if (data!=null)//If not starved
                     {
                         dataQueue.add(data);//add data to data queue
                     }
                     data = sequence.get(sPos+2).operations(currentTime); //Fetch stage 3 or 5 input
                     if (data!=null)//if not blocked
                     {
                         dataQueue.add(data);
                     }
                     break;
                 case 3://For stage 2b or 4b
                 case 6:
                     data = sequence.get(sPos-2).operations(currentTime); //1 or 3
                     if (data!=null)
                     {
                         dataQueue.add(data);
                     }
                     data = sequence.get(sPos+1).operations(currentTime); //3 or 5
                     if (data!=null)
                     {
                         dataQueue.add(data);
                     }
                     break;
                 case 7://for stage 5
                     data = sequence.get(sPos-1).operations(currentTime); //4b
                     if (data!=null)
                     {
                         dataQueue.add(data);
                     }
                     data = sequence.get(sPos-2).operations(currentTime); //4a
                     if (data!=null)
                     {
                         dataQueue.add(data);
                     }
                     break;
                 default://s0
                     data = sequence.get(sPos+1).operations(currentTime); //1
                     if (data!=null)
                     {
                         dataQueue.add(data);
                     }
                     break;
             }
         }
     }

     public String getAvgQueueTime(Stage stage)//Compute and return average time spent in queue
     {
         Queue<Item> items = ((FinishStage)s5).getOutputQueue();//Get items from output of Stage 5
         double queueTime = 0;
         for(Item prodItem: items)//For each item in items Array
         {
             queueTime = queueTime + prodItem.getTimeInQueue(stage.getStageName());//Add time spent in a queue of item to queueTime
         }
         double avgQueueTime=(queueTime/items.size());
         return String.format("%.2f",avgQueueTime);//return average
     }


     public int getProdPath(int path)//Returns number of items that have taken the specified producion path
     {
         Queue<Item> items = ((FinishStage)s5).getOutputQueue();
         int itemCount = 0;
         switch(path)
         {
             case 1:
                 for(Item prodItem: items)//For each item
                 {
                     if (prodItem.getStages().equals("s0 s1 s2a s3 s4a "))//If item takes this path
                     {
                         itemCount++;
                     }
                 }
                 return itemCount;
             case 2:
                 for(Item prodItem: items)//For each item
                 {
                     if (prodItem.getStages().equals("s0 s1 s2a s3 s4b "))//If item takes this path
                     {
                         itemCount++;
                     }
                 }
                 return itemCount;
             case 3:
                 for(Item prodItem: items)//For each item
                 {
                     if (prodItem.getStages().equals("s0 s1 s2b s3 s4a "))//If item takes this path
                     {
                         itemCount++;
                     }
                 }
                 return itemCount;
             case 4:
                 for(Item prodItem: items)//For each item
                 {
                     if (prodItem.getStages().equals("s0 s1 s2b s3 s4b "))//If item takes this path
                     {
                         itemCount++;
                     }
                 }
                 return itemCount;
             default:
                 throw new IllegalStateException("Path for item unaccounted.");
         }
     }

     //Output
     public String toString(){
         String output = "";
         //Q1
         output +=  "Production Stations: \n-----------------------------------------------------------------\n";
         output +=  "Stage:\t\tWork[%]\t\tStarve[t]\t\tBlock[t]\n"; //Q1 column labels
         output +=   s0.toString()+"\n";
         output +=   s1.toString()+"\n";
         output +=   s2a.toString()+"\n";
         output +=   s2b.toString()+"\n";
         output +=   s3.toString()+"\n";
         output +=   s4a.toString()+"\n";
         output +=   s4b.toString()+"\n";
         output +=   s5.toString()+"\n";
         //Q2
         output += "\nStorage Queues:\n";
         output += "-----------------------------------\n";
         output += "Queue \t  AvgTime[t] \t AvgItems \n";// Q2 column labels
         //Output average time an item was in each queue and average items in each queue
         output += "Q01 \t  "+ getAvgQueueTime(s0)+" \t\t "+ s0.getAverageSize()+"\n";
         output += "Q12 \t  " + getAvgQueueTime(s1)+" \t\t "+ s1.getAverageSize()+"\n";
         output += "Q23 \t  "+ getAvgQueueTime(s2a)+" \t\t "+ s2a.getAverageSize()+"\n";
         output += "Q34 \t  "+ getAvgQueueTime(s3)+" \t\t "+ s3.getAverageSize()+"\n";
         output += "Q45 \t  "+ getAvgQueueTime(s4a)+" \t\t "+ s4a.getAverageSize()+"\n";
         output += "\n\n";
         //Q3
         //Output each possible path an item can take and the number of items that have taken that path
         output += "Production Paths:\n";//Q3 label
         output += "------------------\n";
         output += "S2a -> S4a: " + getProdPath(1)+"\n";
         output += "S2a -> S4b: " + getProdPath(2)+"\n";
         output += "S2b -> S4a: " + getProdPath(3)+"\n";
         output += "S2b -> S4b: " + getProdPath(4)+"\n";
         return output;
     }
 }