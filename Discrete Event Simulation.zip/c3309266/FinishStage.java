/*
 * ======================================================================
 * Written by: C3309266, Akshata Dhuraji
 * Written for: SENG2200 Programming Languages & Paradigms Assignment3
 * ======================================================================
 * Description: Processing for the Finish stage of the production line, extends stage
 */
import java.util.*;

class FinishStage extends Stage {

    public FinishStage(Queue<Item> InputQueue_, int Mean_, double timeRange, int Size_)//constructor
    {
        inputQueue = InputQueue_;//Output from previous stage becomes final stage input
        outputQueue = new LinkedList<Item>();
        currentItem = null;
        mean = Mean_;
        range = timeRange;
        maxSize = Size_;
        stageName = "s5";
        starved = false;
        inputTimeAt = new double[maxSize+1];
        outputTimeAt = new double[20];
    }

    @Override
    public Time operations(double currentTime) //Create item, put in output, create event from stats and returns event
    {
        if (!isCompleted(currentTime))//If finished
        {
            return null;
        }
        if (!inputQueue.isEmpty())//If not blocked
        {
            if (starved)//If starved
            {
                starved = false;
                setUnStarveTime(currentTime);
            }
        }
        else
        {
            starved = true;
            setStarveTime(currentTime);
            return null;
        }
        updateInputTimeAt(currentTime, inputQueue.size()); //update time for sizes of input queue
        itemProcessing();

        currentItem.setStage(this); //set items current stage
        Time data;
        data=timeProcessing(currentTime);
        return data;
    }

    public void itemProcessing(){
        currentItem = inputQueue.poll(); //take item from input queue
        outputQueue.add(currentItem); //put it in outputQueue
    }

    public Time timeProcessing(double currentTime){
        Time data = new Time();
        data.setBeginTime(currentTime); //set production start time
        double prodTime = measureProdTime(currentTime);//Find production time
        timeDone = currentTime+prodTime;//Find time item finishes in stage
        currentItem.setTimeInQueue(stageName, prodTime); //set time spent in stage
        data.setFinishTime(timeDone); //set time item exits production in an event
        data.setStage(this); //Insert current stage in event
        return data;
    }
    @Override //From Stage
    public boolean chkBlocked()//Return block status
    {
        return false;//Always false cause last stage never blocks
    }

    @Override
    public String getTotalTimeBlock()//Return total block time
    {
        return String.format("%.2f",0.0);//Final stage is never blocked
    }

    public Queue<Item> getOutputQueue()//Returns output queue
    {
        return outputQueue;
    }

    public String toString(){
        String printer = "";
        printer += getStageName()+ "\t\t\t" +processingTime()+ "\t\t" +getTotalTimeStarve()+ "\t\t" +getTotalTimeBlock();
        return printer;
    }
}