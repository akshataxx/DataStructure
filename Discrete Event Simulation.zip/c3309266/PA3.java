/*
 * ======================================================================
 * Written by: C3309266, Akshata Dhuraji
 * Written for: SENG2200 Programming Languages & Paradigms Assignment3
 * ======================================================================
 * Description: Main class to read user input and pass it to ProductionLine for processing and display the output
 */

import java.util.*;
import java.io.*;

public class PA3{
    public static void main(String args[]) throws IOException{
        System.out.print('\u000C'); //Clear screen
        Scanner Console = new Scanner(System.in);

        ProductionLine productionLine;
        int m, qMax;
        double n;

        m = Integer.parseInt(args[0]);//Average processing time of an item in a stage
        n = Double.parseDouble(args[1]);//Range of processing time in a stage
        qMax = Integer.parseInt(args[2]);//Capacity ofstorage

        //End the program if negative parameters are provided
        //The interstage storage capacities "qMax" will always be greater than 1 as per the assign specs
        if (args.length != 3 || m < 0 || n < 0 || qMax < 1){
            //end program
            System.out.println("Not enough Parameters or wrong parameters given");
            System.out.println("ERROR: Qmax input must be greater than 1.");
        }
        else {
            productionLine = new ProductionLine(m,n,qMax);
            productionLine.execute();
            System.out.println(productionLine.toString());
        }
        Console.close();
    }
}