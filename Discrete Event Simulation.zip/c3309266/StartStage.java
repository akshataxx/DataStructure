/*
 * ======================================================================
 * Written by: C3309266, Akshata Dhuraji
 * Written for: SENG2200 Programming Languages & Paradigms Assignment3
 * ======================================================================
 * Description: Processing for the Finish stage of the production line, extends stage
 */
import java.util.*;

public class StartStage extends Stage {

    public StartStage(int Mean_, double timeRange, int Size_)//Constructor
    {
        outputQueue = new LinkedList<Item>();//Stores items that have finished in current stage
        currentItem = null;
        mean = Mean_;
        range = timeRange;
        stageName = "s0";
        maxSize = Size_;
        outputTimeAt = new double[maxSize+1];
    }

    @Override//From Stage
    public boolean chkStarved()
    {
        return false;//First stage never starves
    }

    @Override//From Stage
    public void setStarveTime(double currentTime)//Not used in first stage
    {
        throw new IllegalStateException("start stage cannot starve");
    }

    @Override//From Stage
    public void setUnStarveTime(double currentTime)//Not used in first stage
    {
        throw new IllegalStateException("start stage cannot starve");
    }


    @Override//From Stage
    public String getTotalTimeStarve()
    {
        return String.format("%.2f",0.0);//Always zero since first stage never starves
    }

    @Override//From Stage
    public Time operations(double currentTime) //Create item, put in output, create event from stats and returns event
    {
        if (!isCompleted(currentTime)) //check if finished processing
        {
            return null;
        }
        if (outputQueue.size()>=maxSize) //check if blocked
        {
            blocked = true;
            setBlockTime(currentTime);
            return null;
        }
        else
        {
            if (blocked)
            {
                blocked = false;
                setUnblockTime(currentTime);
            }
        }
        currentItem = new Item(); //creates item
        itemProcessing();

        updateOutputTimeAt(currentTime, outputQueue.size());//update time a queue is at a particular size
        currentItem.setStage(this);//Set current items current stage to this stage

        Time data;
        data=timeProcessing(currentTime);
        return data;
    }

    public void itemProcessing(){ //since this is start stage there's no previous input queue
        outputQueue.add(currentItem); //add item to outputQueue
    }

    public Time timeProcessing(double currentTime){
        Time data = new Time();
        data.setBeginTime(currentTime);//Set production start time
        double prodTime = measureProdTime(currentTime);//Find production time
        timeDone = currentTime+prodTime;//Calc time item finishes prod in this stage
        currentItem.setTimeInQueue(stageName, prodTime);
        data.setFinishTime(timeDone);
        data.setStage(this);
        return data;
    }
    public Queue<Item> getQueue()//Return queue storing output of stage
    {
        return outputQueue;
    }

    public String toString(){// return output for startstage
        String printer = "";
        printer += getStageName()+ "\t\t\t" +processingTime()+ "\t\t" +getTotalTimeStarve()+ "\t\t\t" +getTotalTimeBlock();
        return printer;
    }

}