/*
 * ======================================================================
 * Written by: C3309266, Akshata Dhuraji
 * Written for: SENG2200 Programming Languages & Paradigms Assignment3
 * ======================================================================
 * Description: Item class stores time spent in queue used for calculating average time spent in queue and stges visited
 */
public class Item {
    private double[] timeInQueue; //time spent in queues
    private Stage[] stages;//Stages visited
    private String itemcode;//assign the id to item

    public Item()//constructor
    {
        timeInQueue = new double[5];
        stages = new Stage[5];
        getID generateID = getID.getInstance();//call to Singleton class
        generateID.nextID(); //unique id generated for each item
        itemcode = generateID.nextID();
        int i = 0,j=0;
        while (i < stages.length)//initialise array of stages visited
        {
            stages[i] = null;
            i++;
        }

        while(j < timeInQueue.length) //initialise array of time spent in queues
        {
            timeInQueue[j] = 0.0;
            j++;
        }
    }


    public void setTimeInQueue(String stage, double time) //Takes stage name and time spent in a stage and inserts time into appropriate index
    {
        if(stage=="s0"){
            timeInQueue[0] = time;
            return;
        }
        else if(stage=="s1"){
            timeInQueue[1] = time;
            return;
        }
        else if(stage=="s2a"){
            timeInQueue[2] = time;
            return;
        }
        else if(stage=="s2b"){
            timeInQueue[2] = time;
            return;
        }
        else if(stage== "s3"){
            timeInQueue[3] = time;
            return;
        }
        else if(stage=="s4a"){
            timeInQueue[4] = time;
            return;
        }
        else if(stage=="s4b"){
            timeInQueue[4] = time;
            return;
        }
        else{
            return;
        }
    }

    public void setStage(Stage stage)
    {
        for (int i=0; i<5; i++)
        {
            if (stages[i] == null)
            {
                stages[i] = stage;
                return;
            }
        }
    }

    public String getStages()//Convert stages array into a string and returns it
    {
        String stageNames = "";
        int i=0;
        while(i<stages.length)
        {
            stageNames = stageNames + stages[i].getStageName() + " ";
            i++;
        }
        return stageNames;
    }

    public double getTimeInQueue(String stage)//Returns time spent in the queue specified by input stage
    {
        if (stage=="s0"){
            return timeInQueue[0];
        }
        else if(stage== "s1"){
            return timeInQueue[1];
        }
        else if(stage=="s2a"){
            return timeInQueue[2];
        }
        else if(stage=="s2b"){
            return timeInQueue[2];
        }
        else if(stage=="s3"){
            return timeInQueue[3];
        }
        else if(stage=="s4a"){
            return timeInQueue[4];
        }
        else if(stage=="s4b"){
            return timeInQueue[4];
        }
        else{
            throw new IllegalStateException("Invalid stage");
        }
    }
}