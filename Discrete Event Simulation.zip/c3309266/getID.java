/*
 * ======================================================================
 * Written by: C3309266, Akshata Dhuraji
 * Written for: SENG2200 Programming Languages & Paradigms Assignment3
 * ======================================================================
 * Description: Singleton class with getInstance() method assigns unique id to every item
 */
import java.util.Random;

public class getID{

    private static getID instance;
    private String ID;
    private getID(){}

    public static getID getInstance(){
        synchronized(getID.class){
            if(instance ==null){
                instance = new getID();
            }
            return instance;
        }
    }
    public String nextID(){
        Random r = new Random();

        this.ID="";
        int rnd = r.nextInt(10);
        this.ID = String.valueOf(rnd);
        int i=0;
        while(i<9){
            rnd=r.nextInt(10);
            this.ID +=String.valueOf(rnd);
            i++;
        }
        return this.ID;
    }
}