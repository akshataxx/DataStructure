/*
 * ======================================================================
 * Written by: C3309266, Akshata Dhuraji
 * Written for: SENG2200 Programming Languages & Paradigms Assignment2
 * ======================================================================
 * Description : Point Node to accept the different shape coordinates, calculate the distance and returns the output
 * PreCondition :  Design to pass the coordinates of shapes
 * PostCondition : Return the output as a string
 */

import java.lang.Math;

public class Point{
    // declaring variables, x and y coordinates
    private double x;
    private double y;

    // constructor
    public Point(final double x, final double y) {
        // setting x and y coordinates
        this.x = x;
        this.y = y;
    }

    // method to calculate distance from point coordinates to (0, 0)
    public double getDistance() {
        //Calculate the distance of the Point from the origin
        return Math.sqrt((x*y)+(x*y));
    }

    // return point as a string
    public String toString() {//returns the coordinates of the Point as per the format specified in the assignment
        return "("+String.format("%3.2f", x)+","+String.format("%3.2f", y)+")";
    }

    // accessor methods
    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }
}