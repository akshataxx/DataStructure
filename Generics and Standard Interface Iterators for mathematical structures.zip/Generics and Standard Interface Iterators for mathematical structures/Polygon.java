/*
 * ======================================================================
 * Written by: C3309266, Akshata Dhuraji
 * Written for: SENG2200 Programming Languages & Paradigms Assignment2
 * ======================================================================
 * Description :Redesigned Polygon Class from Assignment1 with PlanarShape
 * PreCondition: PlanarShape abstract class and Point class are available
 * PostCondition:Processes coordinates for Polygon
 */
public class Polygon extends PlanarShape{
    // variable and object declaration
    private final Point[] vertices; //array of Point class 
    private double lowestPointFromOrigin;
    private int countofPoints;
    private int counter;
    
    

    // constructor for intialising objects and variables
    public Polygon(final int size){
        vertices = new Point[size];//size of array
        lowestPointFromOrigin = 0;
        countofPoints = size;
        counter = 0;
    }
    // compute area of polygon 
    public double getArea(){
        // declare and initialising method variables
        double area = 0.0; int i=0;
        // formula 
        while (i < (countofPoints-1) ){
            area += ((vertices[i+1].getX() + vertices[i].getX()) * (vertices[i+1].getY() - vertices[i].getY()));
            i++;
           }

        return Math.abs(area) * 0.5;//halfof formula result 
    }

    // add point to the polygon
    public void addPoint(double x, double y) {
        // array of point added as new point
        vertices[counter] = new Point(x, y);
        // loop to check if new point is closer than previous point
        //chkLowestFromOrigin(counter);
        if(counter == 0){
            lowestPointFromOrigin =(vertices[counter].getDistance());  // first point will be set as point closest to origin of polygon
        }
        else if (vertices[counter].getDistance() < vertices[counter-1].getDistance()){
            // set as point closest to origin of polygon
            lowestPointFromOrigin = (vertices[counter].getDistance());
        }
        // iterate number of points
        counter++;
    }

    // accessor method
    public double originDistance(){
        return lowestPointFromOrigin;
    }

    // return string
    public String toString(){
        // string declaration and initialisation
        String output = "POLY=[";

        // Put all the coordinates into a string
        for (int i = 0; i < countofPoints; i++) {
            output +=  vertices[i].toString();
        }

        // output
        return  output + "]: " + String.format("%5.2f", getArea());
    }

}