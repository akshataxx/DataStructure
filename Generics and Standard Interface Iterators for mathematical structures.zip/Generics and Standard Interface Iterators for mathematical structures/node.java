/*
 * ======================================================================
 * Written by: C3309266, Akshata Dhuraji
 * Written for: SENG2200 Programming Languages & Paradigms Assignment2
 * ======================================================================
 * Description : I have used the same node class as in Assignment 1 and modified it to have generics
 * public void setPrevious(node<T> previous)
 * sets the reference to the previous data.Node<T>
 * @param previous
 *
 * public node<S> getPrevious()
 * gets the reference to the previous data.Node<T>
 * @return
 *
 * public S getData()
 * Creates a new data.node<T> with the data provided
 * @param data
 */

public class node<S> {
    // Declaration of private objects and variables of the class
    private S data;
    private node<S> next;
    private node<S> previous;


    // class constructor which is used to instantiate variables and objects
    public node(final S data, node<S> next, node<S> previous) {
        this.data = data;
        this.next = next;
        this.previous = previous;
    }

    // setter methods
    public void setNext(final node<S> next_) {
        next = next_;
    }

    public void setPrevious(final node<S> previous_) {
        previous = previous_;
    }

    // getter methods
    public S getData() {
        return data;
    }

    public node<S> getNext() {
        return next;
    }

    public node<S> getPrevious() {
        return previous;
    }
}
