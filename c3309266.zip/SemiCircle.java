/*
 * ======================================================================
 * Written by: C3309266, Akshata Dhuraji
 * Written for: SENG2200 Programming Languages & Paradigms Assignment2
 * ======================================================================
 * Description :SemiCircle Class with PlanarShape
 * PreCondition: PlanarShape abstract class and Point class are available
 * PostCondition: Processes coordinates for SemiCircle
 */

public class SemiCircle extends PlanarShape{

    // declaring variables
    private Point[] vertices;
    private int count;

    // constructor
    public SemiCircle() {
        vertices = new Point[2];
        // count is intialised 
        count = 0;
    }
    
    //area ofsemicircle
    public double getArea(){
        double radius;
        radius = Math.pow((Math.pow((vertices[1].getX() - vertices[0].getX()),2) + Math.pow((vertices[1].getY() - vertices[0].getY()),2)),0.5);
        
        // pi*r^2 formula computes area of circle, half of circle is semicircle
         return Math.PI * Math.pow(radius, 2)/2;
          
    }

    // add point to the semiCircle
    public void addPoint(final double xInput, final double yInput) {
        vertices[count] = new Point(xInput, yInput);               // adding array of point as a new point
        count++;                                                     // iterate number of points
    }

    public double originDistance(){
        //setting extremity points
        double x2 = vertices[0].getX() -(Math.abs(vertices[0].getY()-vertices[1].getY())); //for calculating origin of distance of first point
        double x3 = vertices[0].getX() +(Math.abs(vertices[0].getY()-vertices[1].getY())); //for calculating origin of distance of first point
        double y2 = vertices[0].getY() +(Math.abs(vertices[0].getX()-vertices[1].getX())); //for calculating origin of distance of second point
        double y3 = vertices[0].getY() -(Math.abs(vertices[0].getX()-vertices[1].getX())); //for calculating origin of distance of second point
        
        Point e1= new Point(x2,y2); //extremity base point one 
        Point e2= new Point(x3,y3); //extremity base point two
        
        double closestDistance = vertices[0].getDistance();
        //  comparing the closest point to origin
        for(int i = 0; i < vertices.length; i++) {
            if(vertices[i].getDistance() < closestDistance){
                closestDistance = vertices[i].getDistance();
            }
        }
        //comparing extremity point to lowest from origin
        if(e1.getDistance() < closestDistance){
            closestDistance = e1.getDistance();
        }

        // comparing extremity point to lowest from origin
        if(e2.getDistance() < closestDistance){
            closestDistance = e2.getDistance();
        }

        return closestDistance;
    }

    public String toString(){
        String row = "SEMI=";

        row += "[" + vertices[0].toString() + "" + vertices[1].toString() + "]: " + String.format("%5.2f", getArea());       // concatenate line

        return row;
    }
}
