/*
 * ======================================================================
 * Written by: C3309266, Akshata Dhuraji
 * Written for: SENG2200 Programming Languages & Paradigms Assignment2
 * ======================================================================
 * Description :Circle Class with PlanarShape
 * PreCondition: PlanarShape abstract class and Point class are available
 * PostCondition: Processes coordinates for Circle
 */

public class Circle extends PlanarShape{

    //variables and objects declared
    private Point centre;
    private double r;

    // constructor
    public Circle(double r) {
        centre= new Point(0,0);
        // instantiating radius
        this.r = r;
    }

    public double getArea(){
        // method for calculating area of circle = pi * r^2
        return (Math.PI * Math.pow(r, 2));
    }

    public double originDistance(){
        // distance = (distance from origin of centre) - (radius of circle)
        return(centre.getDistance() - Math.abs(r));
    }

    public void addPoint(final double xIn, final double yIn) {
        // adding array as a new point
        centre = new Point(xIn, yIn);
    }

    public String toString(){
        String row = "CIRC=";

        //line concatenation
        row += "[" + centre.toString() + " " + String.format("%3.2f", r) + "]: " + String.format("%5.2f", getArea());

        return row;
    }
}
