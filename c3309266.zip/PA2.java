/*
 * ======================================================================
 * Written by: C3309266, Akshata Dhuraji
 * Written for: SENG2200 Programming Languages & Paradigms Assignment2
 * ======================================================================
 * Description : Class PA2
 * Main program to read the input file and process the coordinates and prints the sorted and unsorted list
 *
 * processFile(input)
 * Description : reads the coordinates from input file and passes it to the factory function for creating patterns
 * PreCondition : input file is provided
 * PostCondition : sorted and unsorted list of patterns is generated
 *
 * PlanarShape patternFactory(String pattern)
 * Description : Accepts the coordinates and returns the pattern i.e. object of PlanarShape used
 * for addition to the sorted and unsorted list by the readFile class
 */

// importing java libraries (file scanner and string output)
import java.io.*;
import java.util.*;

class PA2{
    static LinkedList<PlanarShape> unsortedList   = new LinkedList<PlanarShape>();        // unsorted linked list
    static LinkedList<PlanarShape> sortedList = new LinkedList<PlanarShape>();            // sorted linked list

    public static void main(final String[] args) throws IOException {//takes input file and calls processFile function to process it
        System.out.print('\u000C'); //clear screen

        //check if file name argument is given
        if (args.length == 0) {
            System.out.println(" No arguments were given");
        }
        // execute java PA2
        else {
            final Scanner input = new Scanner(new File(args[0]));
            //Prints the name of the file
            System.out.println("File: " + System.getProperty("user.dir") + "\\" + input + "\n");

            //reads the file and passes the input to the  factory method
            processFile(input);

            input.close();        // close the file

            // print unsorted list
            System.out.println("Unsorted List:");
            System.out.println(unsortedList.toString());

            // print sorted list
            System.out.println("Sorted List:");
            System.out.println(sortedList.toString());
        }
    }

    public static void processFile (Scanner input) { //supporting function to main, to read the file and call factory function
        String nextData = "";
        try {
            // scanner reads file until the end of file
            while (input.hasNext()) {
                nextData = input.next();                                    // declare string and assign input

                // If 'P' call to section 2.5, polygon class
                if (nextData.equals("P")) {
                    // creating line to send to factory function
                    String myStr = "P";
                    final int numOfPoints = input.nextInt();                // next int is assumed to be number of points
                    myStr += " ";
                    myStr += numOfPoints;

                    // creating line of coordinates to send to factory function
                    for(int i=1;i <= numOfPoints;i++) {
                        double x = input.nextDouble();
                        myStr += " ";
                        myStr += x;

                        double y = input.nextDouble();
                        myStr += " ";
                        myStr += y;
                    }
                    PlanarShape pattern = patternFactory(myStr);// sending  string
                    makeList(pattern);//  add pattern to the list
                }

                // if 'C' call to section 2.6,  Circle class
                else if (nextData.equals("C")) {
                    // creating line to send to factory function
                    String myStr = "C ";
                    double x = input.nextDouble();
                    double y = input.nextDouble();
                    double r = input.nextDouble();            // radius

                    // creating line to send to factory function
                    myStr += x + " " + y + " " + r;

                    PlanarShape pattern = patternFactory(myStr);
                    makeList(pattern); //  add pattern to the list

                }

                // If 'S' call to section 2.7, Semicircle class
                else if (nextData.equals("S")) {
                    // creating line to send to factory function
                    String myStr = "S ";
                    // concatenating string
                    double x = input.nextDouble();
                    double y = input.nextDouble();
                    double xx = input.nextDouble();
                    double yy = input.nextDouble();
                    myStr += x + " " + y + " " + xx + " " + yy;

                    PlanarShape pattern = patternFactory(myStr);
                    makeList(pattern); //  add pattern to the list
                }
            }
        }
        // file reading error
        catch (Exception exception) {
            System.out.println("Error reading input file: " + exception);
        }
    }


    //factory function to process the shapes based on the input from the file
    public static PlanarShape patternFactory(String pattern){

        // case: string is null
        if(pattern == null){
            return null;
        }

         final Scanner input = new Scanner(pattern);// string scanner
         
        // scanner keeps looking for next character
        while (input.hasNext()) {
            String nextData = input.next();// declare string and assign input
            switch (nextData){
                // Polygon found
                case "P":
                    final int numOfPoints = input.nextInt();// next int is the number of points in the row
                    final PlanarShape polygonObject = new Polygon(numOfPoints);// new polygon object with number of points
                    final Point[] vertices = new Point[numOfPoints];// declare point array and set number of elements as number of points
                    
                    int j = 0;                                // declare int variables and instantiate
                    for (int i=1;i <= numOfPoints;i++) {
                        // x and y alternates
                        final double x = input.nextDouble();
                        final double y = input.nextDouble();

                        vertices[j] = new Point(x, y);            // create new point element

                        polygonObject.addPoint(x, y);            // inserting points

                        // iterate after each loop
                        j++;
                    }

                    // return proper object type
                    return polygonObject;

                // Circle found
                case "C":
                    double x = input.nextDouble();
                    double y = input.nextDouble();
                    double r = input.nextDouble();            // radius

                    // create new circle using parameters
                    PlanarShape circleObject  = new Circle(r);
                    circleObject.addPoint(x, y);

                    // return proper object type
                    return circleObject;

                // Semicircle found
                case "S":
                    // new semicircle
                    PlanarShape semiCircleObject = new SemiCircle();
                    int i=0;
                    // inserting points
                    while( i < 2 ){
                        double x1 = input.nextDouble();
                        double y1 = input.nextDouble();
                        semiCircleObject.addPoint(x1, y1);
                        i++;
                    }

                    // return proper object type
                    return semiCircleObject;
            }
        }
        return null;
    }
    
    public static void makeList(PlanarShape pat){
        unsortedList.append(pat);
        sortedList.insertInOrder(pat);
    }
}
