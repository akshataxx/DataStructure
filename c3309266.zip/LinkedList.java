/*
 * ======================================================================
 * Written by: C3309266, Akshata Dhuraji
 * Written for: SENG2200 Programming Languages & Paradigms Assignment2
 * ======================================================================
 * Description : Circular Linkedlist extends PlanarShape and implements Iterable to handle the nodes.
 */
import java.util.Iterator;

public class LinkedList<S extends PlanarShape> implements Iterable<S> {
    // Declaration of private variables and objects of the class
    private node<S> sentinel; //Creates the sentinel node
    private int size;

    //Constructor used to instantiate the private variables
    public LinkedList() {
        sentinel = new node<>(null,null,null);
        sentinel.setNext(sentinel);
        sentinel.setPrevious(sentinel);
        size = 0;
    }

    // method to add data at the end of the list
    public void append(S pattern) {
        node<S> newNode = sentinel.getPrevious();
        node<S> temp = new node<>(pattern,null,null);

        temp.setNext(sentinel);
        temp.setPrevious(newNode);
        newNode.setNext(temp);
        sentinel.setPrevious(temp);

        size++;
    }

    // method to add data at the beginning of the list
     public void prepend(S pattern) {
        node<S> newNode = sentinel.getNext();
        node<S> temp = new node<S>(pattern,null,null);

        temp.setNext(newNode);
        temp.setPrevious(sentinel);
        newNode.setPrevious(temp);
        sentinel.setNext(temp);

        size++;
    }

    //  removes an element from the list beginning
    public S remove() {

        node<S> current = sentinel.getNext();

        // condition to check whether there are nodes in the linked list
        if (size > 0) {
            // condition to check whether there is one node in the linked list

            if (size == 1) {
                sentinel = null;
            }

            // a temp node is made to resemble sentinel
            else {
                node<S> temp = sentinel;

                // the previous and next nodes are referenced to remove the original sentinel
                sentinel.getNext().setPrevious(sentinel.getPrevious());
                sentinel.getPrevious().setNext(sentinel.getNext());

                // current becomes the new sentinel
                sentinel = current;

                // decrement
                size--;
                return temp.getData(); //return data
            }
        }
        // returns the data in current node
        return current.getData();
    }

    public void insertInOrder(S data) {

        node<S> recentNode = new node<>(data,null,null);
        node<S> nextNode = this.sentinel.getNext();

        while(nextNode != this.sentinel) {
            //checks for the recentNode value is in sorted order
            //if item passed in is smaller, then add
            if(recentNode.getData().compareTo(nextNode.getData()) <= 0) {
                //insert
                recentNode.setNext(nextNode);
                recentNode.setPrevious(nextNode.getPrevious());
                nextNode.getPrevious().setNext(recentNode);
                nextNode.setPrevious(recentNode);
                break;
            }

            nextNode = nextNode.getNext();
        }

        //add last node
        if (nextNode == this.sentinel) {
            recentNode.setPrevious(this.sentinel.getPrevious());
            recentNode.setNext(this.sentinel);
            this.sentinel.getPrevious().setNext(recentNode);
            this.sentinel.setPrevious(recentNode);
        }
    }

    // method returning string from list of polygon
    public String toString() {
        // string output is declared and instantiated
        String output = "";

        // loop for the node S
        Iterator<S> iterator = iterator();

        // while loop is being implemented to check if next element exists
        while(iterator.hasNext()){
            output += iterator.next().toString();
            output += "\n";
        }

        // output string returned
        return output;
    }

    private class LinkedListIterator implements Iterator<S>{
        // private variable declaration
        private node<S> current;

        public LinkedListIterator() {
            // instantiate private variables
            current = sentinel;
        }

        //checks for all items until list has reached sentinel.
        public boolean hasNext() {
            // if node after current node is sentinel (full loop)
             if( current.getNext() == sentinel){
                return false;
            }
            // if node after current node is not sentinel
            else{
                return true;
            }
        }

        // sets current to current.getNext() returns the currents data
        public S next() {
            current = current.getNext();
            return current.getData();
        }
    }
    // iterator method
    public Iterator<S> iterator() {
        return new LinkedListIterator();
    }
}
