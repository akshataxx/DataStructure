/*
* ======================================================================
* Written by: C3309266, Akshata Dhuraji
* Written for: SENG2200 Programming Languages & Paradigms Assignment2
* ======================================================================
* Description : Abstract PlanarShape class.
*
* public abstract String toString()
* Description: It has an abstract toString()method for printing results.
*
* public abstract double getArea()
* Description: An abstract area() method and an abstract
*
* public abstract double originDistance()
* Description: used to compare PlanarShape objects
*
* public interface Comparable
* Description: The standard Comparable<T> interface added based on the lecture slides
*/

public abstract class PlanarShape implements Comparable<PlanarShape>{

    // common methods
    public abstract String toString();
    public abstract double originDistance();
    public abstract double getArea();
    public abstract void addPoint(double x, double y);

    @Override
    public int compareTo(PlanarShape ps){

        if(ps == null){
            return 1;
        }

        // if difference in area between 2 shapes is less than 0.05%
        double diff = (Math.abs(this.getArea() - ps.getArea()));
        if(diff <= 0.005){ //Check if this is within 0.05% units
            if(this.originDistance() > ps.originDistance()){
                return 1;
            }
            return -1;
        }

        // if previous shape is smaller  than the new shape
        if(this.getArea() < ps.getArea()){
            return 1;
        }

        // if previous shape is equal to the  new shape
        else if(this.getArea() == ps.getArea()){
            return 0;
        }

        // if Previous shape is greater than the new shape
        else{
            return -1;
        }
    }
}
